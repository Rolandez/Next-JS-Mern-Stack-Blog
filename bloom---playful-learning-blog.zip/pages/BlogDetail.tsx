// Deprecated: Use frontend/pages/BlogDetail.tsx instead.
export {};