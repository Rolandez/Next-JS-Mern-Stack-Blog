// Deprecated: Use frontend/pages/Home.tsx instead.
export {};