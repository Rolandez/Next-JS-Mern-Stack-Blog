// Deprecated: Use frontend/pages/AdminDashboard.tsx instead.
export {};