
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './frontend/context/AuthContext';
import Navbar from './frontend/components/Navbar';
import Footer from './frontend/components/Footer';
import Home from './frontend/pages/Home';
import BlogDetail from './frontend/pages/BlogDetail';
import AdminDashboard from './frontend/pages/AdminDashboard';
import SignIn from './frontend/pages/SignIn';

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen flex flex-col">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/blog/:slug" element={<BlogDetail />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/signin" element={<SignIn />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
};

export default App;
