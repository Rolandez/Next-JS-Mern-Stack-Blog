// Deprecated: Use frontend/components/PostCard.tsx instead.
export {};