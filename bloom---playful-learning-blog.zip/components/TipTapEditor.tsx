// Deprecated: Use frontend/components/TipTapEditor.tsx instead.
export {};