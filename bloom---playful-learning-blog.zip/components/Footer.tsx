// Deprecated: Use frontend/components/Footer.tsx instead.
export {};