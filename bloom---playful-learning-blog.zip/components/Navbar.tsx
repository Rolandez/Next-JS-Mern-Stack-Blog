// Deprecated: Use frontend/components/Navbar.tsx instead.
export {};