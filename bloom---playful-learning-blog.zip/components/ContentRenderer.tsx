// Deprecated: Use frontend/components/ContentRenderer.tsx instead.
export {};