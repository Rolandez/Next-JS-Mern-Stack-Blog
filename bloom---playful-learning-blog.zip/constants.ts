
import { BlogPost } from './types';

export const INITIAL_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'How to Spark Creativity in Children',
    slug: 'sparking-creativity',
    excerpt: 'Discover simple daily activities that help children think outside the box and embrace their imagination.',
    content: {
      type: 'doc',
      content: [
        { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: 'Understanding Creativity' }] },
        { type: 'paragraph', content: [{ type: 'text', text: 'Creativity is not just about painting or drawing; it is a way of problem-solving and thinking.' }] },
        { type: 'heading', attrs: { level: 3 }, content: [{ type: 'text', text: 'Practical Tips' }] },
        { 
          type: 'bulletList', 
          content: [
            { type: 'listItem', content: [{ type: 'paragraph', content: [{ type: 'text', text: 'Let them get messy.' }] }] },
            { type: 'listItem', content: [{ type: 'paragraph', content: [{ type: 'text', text: 'Encourage "Why" questions.' }] }] },
            { type: 'listItem', content: [{ type: 'paragraph', content: [{ type: 'text', text: 'Provide open-ended toys.' }] }] }
          ] 
        }
      ]
    },
    featuredImage: 'https://picsum.photos/seed/bloom1/800/500',
    category: 'Education',
    author: 'Sarah Bloom',
    status: 'Published',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  }
];

export const CATEGORIES: string[] = ['Education', 'Creative', 'Storytelling', 'Growth', 'Technology'];
