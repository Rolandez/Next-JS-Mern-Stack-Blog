// Deprecated: Handled by backend/lib/mongoose-shim.ts.
export {};