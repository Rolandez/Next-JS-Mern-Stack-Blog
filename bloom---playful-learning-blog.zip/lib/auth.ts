// Deprecated: Handled by simulated AuthContext and authService.
export {};