
import * as postController from '../../backend/controllers/postController';
import { protect, admin } from '../../backend/middleware/authMiddleware';

// We simulate an API call to decouple the UI from direct DB driver initialization
const apiCall = async (fn: Function) => {
  try {
    return await fn();
  } catch (error: any) {
    console.error("API Simulation Error:", error.message);
    throw error;
  }
};

export const postService = {
  getAllPosts: async () => {
    return await apiCall(() => postController.getPosts());
  },

  getPost: async (slug: string) => {
    return await apiCall(() => postController.getPostBySlug(slug));
  },

  create: async (data: any, token: string) => {
    return await apiCall(async () => {
      const user = await protect(token);
      admin(user);
      return await postController.createPost(data, user.name);
    });
  },

  update: async (id: string, data: any, token: string) => {
    return await apiCall(async () => {
      const user = await protect(token);
      admin(user);
      return await postController.updatePost(id, data);
    });
  },

  remove: async (id: string, token: string) => {
    return await apiCall(async () => {
      const user = await protect(token);
      admin(user);
      return await postController.deletePost(id);
    });
  }
};
