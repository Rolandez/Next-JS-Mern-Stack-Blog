
import * as authController from '../../backend/controllers/authController';

export const authService = {
  login: async (email: string, pass: string) => {
    try {
      // Simulation of fetch('/api/auth/login')
      return await authController.loginUser(email, pass);
    } catch (error: any) {
      throw new Error(error.message || 'Login failed');
    }
  },
  
  getProfile: async (token: string) => {
    // Simulation of fetch('/api/auth/profile') with Bearer token
    const userId = token.split('_')[1];
    return await authController.getUserProfile(userId);
  }
};
