
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User as UserType } from '../../types';
import { authService } from '../services/authService';

interface AuthContextType {
  user: UserType | null;
  token: string | null;
  loading: boolean;
  signIn: (email: string, pass: string) => Promise<boolean>;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserType | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const storedToken = localStorage.getItem('bloom_token');
      const storedUser = localStorage.getItem('bloom_user');
      
      if (storedToken && storedUser) {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      }
      setLoading(false);
    };
    checkAuth();
  }, []);

  const signIn = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const data = await authService.login(email, pass);
      const userData: UserType = {
        id: data._id,
        name: data.name,
        email: data.email,
        role: data.role,
      };
      
      setUser(userData);
      setToken(data.token);
      
      localStorage.setItem('bloom_token', data.token);
      localStorage.setItem('bloom_user', JSON.stringify(userData));
      
      return true;
    } catch (error) {
      console.error(error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const signOut = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('bloom_token');
    localStorage.removeItem('bloom_user');
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
