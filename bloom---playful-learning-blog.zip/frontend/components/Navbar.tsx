
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogOut, ChevronDown, User as UserIcon } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = () => {
    signOut();
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 glass-card mx-4 my-4 rounded-3xl px-6 py-3 md:py-4 shadow-sm border-white/40">
      <div className="flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-orange-400 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-orange-200">B</div>
          <span className="text-2xl font-bold tracking-tight text-slate-800">Bloom</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8 font-medium text-slate-600">
          <Link to="/" className="hover:text-orange-500 transition-colors">Home</Link>
          <Link to="/" className="hover:text-orange-500 transition-colors">Blog</Link>
          <Link to="/#categories" className="hover:text-orange-500 transition-colors">Categories</Link>
          <Link to="/admin" className="hover:text-orange-500 transition-colors">Admin</Link>
        </div>

        <div className="hidden md:block">
          {user ? (
            <div className="relative">
              <button 
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-3 p-1 pr-4 bg-white rounded-2xl border border-slate-100 hover:shadow-md transition-all group"
              >
                <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center text-orange-600 font-bold">
                  {user.name[0]}
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold text-slate-800">{user.name}</div>
                  <div className="text-[10px] text-slate-400 uppercase tracking-widest">{user.role}</div>
                </div>
                <ChevronDown size={14} className={`text-slate-300 transition-transform ${profileOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {profileOpen && (
                <div className="absolute top-full right-0 mt-3 w-48 bg-white rounded-2xl shadow-xl border border-slate-100 p-2 animate-in fade-in slide-in-from-top-2">
                  <Link to="/admin" className="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-50 rounded-xl transition-colors font-bold text-sm">
                    <UserIcon size={18} /> Dashboard
                  </Link>
                  <button 
                    onClick={handleSignOut}
                    className="w-full flex items-center gap-3 px-4 py-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors font-bold text-sm"
                  >
                    <LogOut size={18} /> Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button 
              onClick={() => navigate('/signin')}
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2.5 rounded-2xl font-semibold shadow-lg shadow-orange-100 transition-all hover:scale-105"
            >
              Sign In
            </button>
          )}
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-slate-600" onClick={() => setIsOpen(!isOpen)}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {isOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden mt-4 pb-4 flex flex-col gap-4 animate-in fade-in slide-in-from-top-4">
          <Link to="/" className="p-2 font-medium hover:bg-orange-50 rounded-lg">Home</Link>
          <Link to="/" className="p-2 font-medium hover:bg-orange-50 rounded-lg">Blog</Link>
          <Link to="/admin" className="p-2 font-medium hover:bg-orange-50 rounded-lg">Admin</Link>
          {user ? (
            <button onClick={handleSignOut} className="bg-red-50 text-red-500 w-full py-3 rounded-xl font-bold">Sign Out</button>
          ) : (
            <button onClick={() => navigate('/signin')} className="bg-orange-500 text-white w-full py-3 rounded-xl font-bold">Sign In</button>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
