
import React from 'react';
import { Link } from 'react-router-dom';
import { BlogPost } from '../../types';

interface PostCardProps {
  post: BlogPost;
  variant?: 'featured' | 'standard';
}

const PostCard: React.FC<PostCardProps> = ({ post, variant = 'standard' }) => {
  const isFeatured = variant === 'featured';
  
  return (
    <Link to={`/blog/${post.slug}`} className="group block h-full">
      <article className={`h-full flex flex-col bg-white rounded-[1.5rem] md:rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 transform group-hover:-translate-y-1 ${isFeatured ? 'md:flex-row' : ''}`}>
        <div className={`${isFeatured ? 'md:w-1/2' : 'w-full'} overflow-hidden relative aspect-video md:aspect-auto ${isFeatured ? 'h-full' : 'h-40 md:h-48'}`}>
          <img 
            src={post.featuredImage} 
            alt={post.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-3 left-3">
            <span className="px-3 py-1 rounded-full bg-white/90 backdrop-blur shadow-sm text-[10px] font-bold text-orange-600 uppercase tracking-wider">
              {post.category}
            </span>
          </div>
        </div>
        
        <div className={`p-4 md:p-6 flex flex-col justify-between ${isFeatured ? 'md:w-1/2' : 'flex-grow'}`}>
          <div>
            <div className="flex items-center gap-2 mb-2 text-slate-400 text-[10px] md:text-xs">
              <span className="font-medium text-slate-600 line-clamp-1">{post.author}</span>
              <span>•</span>
              <span className="whitespace-nowrap">{new Date(post.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
            </div>
            <h3 className={`font-bold text-slate-800 leading-tight mb-2 group-hover:text-orange-500 transition-colors ${isFeatured ? 'text-2xl lg:text-4xl' : 'text-base md:text-lg lg:text-xl line-clamp-2'}`}>
              {post.title}
            </h3>
            <p className="text-slate-500 text-xs md:text-sm leading-relaxed line-clamp-2 mb-4">
              {post.excerpt}
            </p>
          </div>
          
          <div className="mt-2 flex items-center gap-2 text-xs md:text-sm font-bold text-orange-500 group-hover:gap-3 transition-all">
            <span>Read More</span>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </div>
        </div>
      </article>
    </Link>
  );
};

export default PostCard;
