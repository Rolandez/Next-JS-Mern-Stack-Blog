
import React from 'react';
import { generateHTML } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';

interface ContentRendererProps {
  content: any;
}

const ContentRenderer: React.FC<ContentRendererProps> = ({ content }) => {
  if (!content) return null;

  const html = generateHTML(content, [
    StarterKit,
    Image,
    Link,
  ]);

  return (
    <div 
      className="prose prose-lg prose-orange max-w-none text-slate-600 leading-relaxed"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};

export default ContentRenderer;
