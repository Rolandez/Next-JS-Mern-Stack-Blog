
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white/60 pt-20 pb-10 px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 border-b border-slate-100 pb-12">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-400 rounded-lg flex items-center justify-center text-white font-bold">B</div>
            <span className="text-xl font-bold">Bloom</span>
          </div>
          <p className="text-slate-500 leading-relaxed">
            Nurturing young minds through the power of storytelling and creative learning.
          </p>
          <div className="flex gap-4">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center hover:bg-orange-100 transition-colors cursor-pointer">
              <svg className="w-5 h-5 text-slate-600" fill="currentColor" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
            </div>
          </div>
        </div>

        <div>
          <h4 className="font-bold mb-6 text-slate-800">Quick Links</h4>
          <ul className="space-y-3 text-slate-500">
            <li className="hover:text-orange-500 cursor-pointer transition-colors">About Us</li>
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Contact</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-6 text-slate-800">Community</h4>
          <ul className="space-y-3 text-slate-500">
            <li className="hover:text-orange-500 cursor-pointer transition-colors">Privacy Policy</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-6 text-slate-800">Newsletter</h4>
          <p className="text-sm text-slate-500 mb-4">Get the latest insights delivered weekly.</p>
          <div className="flex flex-col gap-2">
            <input 
              type="email" 
              placeholder="Your email address" 
              className="bg-white px-4 py-3 rounded-xl border border-slate-200 outline-none focus:border-orange-400"
            />
            <button className="bg-orange-500 text-white font-bold py-3 rounded-xl shadow-lg shadow-orange-100 hover:bg-orange-600 transition-colors">
              Subscribe
            </button>
          </div>
        </div>
      </div>
      <div className="text-center pt-8 text-slate-400 text-sm">
        &copy; {new Date().getFullYear()} Bloom Media. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
