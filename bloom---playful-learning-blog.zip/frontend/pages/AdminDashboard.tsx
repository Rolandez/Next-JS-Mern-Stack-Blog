
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { postService } from '../services/postService';
import { useAuth } from '../context/AuthContext';
import { BlogPost, Category } from '../../types';
import { CATEGORIES } from '../../constants';
import TipTapEditor from '../components/TipTapEditor';
import { FileText, Trash2, X, Plus, Eye, Save, LogOut } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { user, token, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [currentPost, setCurrentPost] = useState<Partial<BlogPost> | null>(null);
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && (!user || user.role !== 'admin')) {
      navigate('/signin');
    }
  }, [user, loading, navigate]);

  const fetchPosts = async () => {
    try {
      const data = await postService.getAllPosts();
      setPosts(data);
    } catch (err) {
      console.error("Failed to fetch posts", err);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const handleCreate = () => {
    const newPost: Partial<BlogPost> = {
      title: '',
      slug: 'new-post-' + Date.now(),
      excerpt: '',
      content: { type: 'doc', content: [] },
      featuredImage: 'https://picsum.photos/seed/' + Math.random() + '/800/500',
      category: 'Education',
      status: 'Draft',
    };
    setCurrentPost(newPost);
    setIsEditing(true);
    setViewMode('edit');
  };

  const editPost = (post: BlogPost) => {
    setCurrentPost(post);
    setIsEditing(true);
    setViewMode('edit');
  };

  const savePost = async () => {
    if (!currentPost || !token) return;
    setIsSubmitting(true);
    try {
      if ((currentPost as any)._id) {
        await postService.update((currentPost as any)._id, currentPost, token);
      } else {
        await postService.create(currentPost, token);
      }
      await fetchPosts();
      setIsEditing(false);
      setCurrentPost(null);
    } catch (err) {
      alert("Error saving post");
    } finally {
      setIsSubmitting(false);
    }
  };

  const deletePost = async (id: string) => {
    if (confirm('Are you sure you want to delete this post?') && token) {
      try {
        await postService.remove(id, token);
        await fetchPosts();
      } catch (err) {
        alert("Error deleting post");
      }
    }
  };

  if (loading || !user) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-orange-100 border-t-orange-500 rounded-full animate-spin"></div>
    </div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
      {isEditing && currentPost ? (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsEditing(false)}
                className="p-3 bg-white rounded-2xl text-slate-400 hover:text-slate-600 shadow-sm transition-colors"
              >
                <X size={24} />
              </button>
              <div>
                <h2 className="text-2xl font-extrabold text-slate-800">
                  {currentPost.title || 'Untitled Post'}
                </h2>
                <p className="text-slate-400 text-sm">Authoring as {user.name}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="bg-white p-1 rounded-2xl shadow-sm flex">
                <button 
                  onClick={() => setViewMode('edit')}
                  className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${viewMode === 'edit' ? 'bg-orange-100 text-orange-600' : 'text-slate-400'}`}
                >
                  <FileText size={16} /> Write
                </button>
                <button 
                  onClick={() => setViewMode('preview')}
                  className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${viewMode === 'preview' ? 'bg-orange-100 text-orange-600' : 'text-slate-400'}`}
                >
                  <Eye size={16} /> Preview
                </button>
              </div>
              <button 
                onClick={savePost}
                disabled={isSubmitting}
                className="bg-orange-500 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all active:scale-95 disabled:opacity-50"
              >
                <Save size={18} /> {isSubmitting ? 'Saving...' : 'Save Article'}
              </button>
            </div>
          </div>

          {viewMode === 'edit' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <input 
                  type="text" 
                  placeholder="Article Title"
                  className="w-full bg-transparent text-4xl md:text-5xl font-extrabold text-slate-800 outline-none border-none placeholder:text-slate-200"
                  value={currentPost.title}
                  onChange={(e) => setCurrentPost({...currentPost, title: e.target.value, slug: e.target.value.toLowerCase().replace(/ /g, '-')})}
                />
                
                <TipTapEditor 
                  content={currentPost.content} 
                  onChange={(json) => setCurrentPost({...currentPost, content: json})} 
                />
              </div>

              <div className="space-y-6">
                <div className="bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100 space-y-6">
                  <h3 className="font-bold text-slate-800 text-lg">Post Settings</h3>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Category</label>
                    <select 
                      className="w-full bg-slate-50 px-4 py-3 rounded-xl outline-none border border-transparent focus:border-orange-200 font-bold text-slate-600"
                      value={currentPost.category}
                      onChange={(e) => setCurrentPost({...currentPost, category: e.target.value as Category})}
                    >
                      {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Status</label>
                    <select 
                      className="w-full bg-slate-50 px-4 py-3 rounded-xl outline-none border border-transparent focus:border-orange-200 font-bold text-slate-600"
                      value={currentPost.status}
                      onChange={(e) => setCurrentPost({...currentPost, status: e.target.value as any})}
                    >
                      <option value="Draft">Draft</option>
                      <option value="Published">Published</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Excerpt</label>
                    <textarea 
                      rows={3}
                      className="w-full bg-slate-50 px-4 py-3 rounded-xl outline-none border border-transparent focus:border-orange-200 resize-none text-sm text-slate-600"
                      value={currentPost.excerpt}
                      onChange={(e) => setCurrentPost({...currentPost, excerpt: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto bg-white rounded-[3rem] p-12 shadow-sm min-h-screen">
               <h1 className="text-5xl font-extrabold mb-8">{currentPost.title}</h1>
               {currentPost.featuredImage && <img src={currentPost.featuredImage} className="w-full rounded-2xl mb-12" />}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-4xl font-extrabold text-slate-800">Content Hub</h1>
              <p className="text-slate-500 mt-2 text-lg">Welcome, {user.name}.</p>
            </div>
            <div className="flex gap-4">
              <button 
                onClick={handleCreate}
                className="bg-orange-500 text-white px-8 py-4 rounded-2xl font-bold shadow-xl shadow-orange-100 hover:bg-orange-600 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                <Plus size={20} /> New Article
              </button>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-3 space-y-6">
               <div className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-slate-100">
                  <div className="divide-y divide-slate-50">
                    {posts.map(post => (
                      <div key={post.slug} className="p-6 hover:bg-slate-50 transition-colors group">
                        <div className="flex items-center gap-6">
                          <img src={post.featuredImage} className="w-20 h-20 rounded-2xl object-cover shadow-sm" />
                          <div className="flex-grow">
                             <h3 className="font-bold text-slate-800 text-lg line-clamp-1 group-hover:text-orange-500 transition-colors">{post.title}</h3>
                             <p className="text-slate-400 text-sm mt-1">{post.status} • {post.category}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <button onClick={() => editPost(post)} className="p-3 bg-white border border-slate-100 rounded-xl text-slate-400 hover:text-orange-500 transition-all"><FileText size={18} /></button>
                            <button onClick={() => deletePost((post as any)._id)} className="p-3 bg-white border border-slate-100 rounded-xl text-slate-400 hover:text-red-500 transition-all"><Trash2 size={18} /></button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
