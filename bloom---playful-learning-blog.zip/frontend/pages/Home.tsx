
import React, { useState, useEffect } from 'react';
import { postService } from '../services/postService';
import { BlogPost } from '../../types';
import PostCard from '../components/PostCard';
import { CATEGORIES } from '../../constants';

const Home: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const data = await postService.getAllPosts();
        setPosts(data.filter((p: any) => p.status === 'Published'));
      } catch (err) {
        console.error("Failed to fetch posts", err);
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  const filteredPosts = posts.filter(post => {
    const matchesCategory = activeCategory === 'All' || post.category === activeCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredPost = posts[0];
  const otherPosts = filteredPosts.filter(p => p.slug !== (featuredPost?.slug && activeCategory === 'All' ? featuredPost.slug : ''));

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
       <div className="w-12 h-12 border-4 border-orange-100 border-t-orange-500 rounded-full animate-spin"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 pb-20">
      <section className="relative min-h-[400px] flex flex-col md:flex-row items-center gap-12 pt-8 pb-16 overflow-hidden">
        <div className="flex-1 space-y-6 relative z-10">
          <div className="inline-block px-4 py-1.5 rounded-full bg-orange-100 text-orange-600 font-bold text-xs md:text-sm tracking-wide">
            WELCOME TO BLOOM
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold text-slate-800 leading-[1.1]">
            Learn, Read & <span className="text-orange-500">Grow</span> Every Day
          </h1>
          <p className="text-lg md:text-xl text-slate-600 leading-relaxed max-w-xl">
            Explore stories, educational guides, and creative tips designed to nurture curiosity.
          </p>
          
          <div className="relative max-w-md group">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <svg className="w-5 h-5 text-slate-400 group-focus-within:text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input 
              type="text" 
              placeholder="Search articles..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white pl-12 pr-6 py-4 rounded-3xl shadow-xl shadow-slate-100 border-none outline-none ring-2 ring-transparent focus:ring-orange-200 transition-all text-base md:text-lg"
            />
          </div>
        </div>

        <div className="flex-1 relative hidden md:block">
          <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-orange-200/50 rounded-full blur-3xl animate-pulse"></div>
          <div className="relative bg-white/40 p-4 rounded-[3rem] backdrop-blur shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500">
             <img 
               src="https://picsum.photos/seed/bloom-hero/600/600" 
               alt="Hero" 
               className="rounded-[2.5rem] w-full aspect-square object-cover"
             />
          </div>
        </div>
      </section>

      {featuredPost && activeCategory === 'All' && !searchQuery && (
        <section className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-800">Featured Article</h2>
            <div className="h-0.5 flex-grow mx-8 bg-slate-100 hidden md:block"></div>
          </div>
          <PostCard post={featuredPost} variant="featured" />
        </section>
      )}

      <section id="categories" className="mb-10">
        <div className="flex items-center gap-3 overflow-x-auto pb-4 no-scrollbar">
          <button 
            onClick={() => setActiveCategory('All')}
            className={`px-6 py-2.5 rounded-2xl font-bold transition-all whitespace-nowrap text-sm ${activeCategory === 'All' ? 'bg-orange-500 text-white shadow-lg shadow-orange-100' : 'bg-white text-slate-500 hover:bg-orange-50'}`}
          >
            All Articles
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2.5 rounded-2xl font-bold transition-all whitespace-nowrap text-sm ${activeCategory === cat ? 'bg-orange-500 text-white shadow-lg shadow-orange-100' : 'bg-white text-slate-500 hover:bg-orange-50'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 lg:gap-8">
        {otherPosts.map(post => (
          <PostCard key={post.slug} post={post} />
        ))}
      </section>
    </div>
  );
};

export default Home;
