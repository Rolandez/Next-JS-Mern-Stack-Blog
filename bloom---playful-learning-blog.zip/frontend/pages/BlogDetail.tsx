
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BlogPost } from '../../types';
import { postService } from '../services/postService';
import ContentRenderer from '../components/ContentRenderer';

const BlogDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      if (slug) {
        try {
          const found = await postService.getPost(slug);
          setPost(found || null);
        } catch (err) {
          console.error(err);
        } finally {
          setLoading(false);
        }
      }
    };
    fetchPost();
    window.scrollTo(0, 0);
  }, [slug]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
       <div className="w-12 h-12 border-4 border-orange-100 border-t-orange-500 rounded-full animate-spin"></div>
    </div>
  );

  if (!post) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-40 text-center">
        <h2 className="text-4xl font-bold mb-4">Post not found</h2>
        <Link to="/" className="text-orange-500 font-bold underline text-xl">Back to home</Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-12 animate-in fade-in duration-700">
      <Link to="/" className="inline-flex items-center gap-2 text-slate-400 font-bold mb-12 hover:text-orange-500 transition-colors group">
        <div className="p-2 bg-white rounded-xl shadow-sm group-hover:bg-orange-50 transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
        </div>
        Back to Stories
      </Link>

      <header className="mb-12">
        <div className="flex items-center gap-3 mb-6">
          <span className="px-4 py-1 rounded-full bg-orange-100 text-orange-600 font-bold text-xs uppercase tracking-wider">
            {post.category}
          </span>
          <span className="text-slate-400 text-sm font-medium">
            {new Date(post.createdAt).toLocaleDateString()}
          </span>
        </div>
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-800 leading-tight mb-8">
          {post.title}
        </h1>
        <div className="flex items-center justify-between p-6 bg-white rounded-[2rem] shadow-sm border border-slate-100">
          <div className="flex items-center gap-4">
             <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center text-orange-600 font-bold text-xl">
               {post.author[0]}
             </div>
             <div>
               <div className="font-bold text-slate-800 text-lg">{post.author}</div>
               <div className="text-xs text-slate-400 uppercase tracking-widest font-bold">Contributor</div>
             </div>
          </div>
        </div>
      </header>

      {post.featuredImage && (
        <img 
          src={post.featuredImage} 
          alt={post.title} 
          className="w-full aspect-video object-cover rounded-[3rem] shadow-2xl mb-16"
        />
      )}

      <div className="mb-20">
        <ContentRenderer content={post.content} />
      </div>
    </div>
  );
};

export default BlogDetail;
