
import User from '../models/User';

// Simulated JWT secret
const JWT_SECRET = "bloom_secret_key_2025";

export const protect = async (token: string | null) => {
  if (!token) {
    throw new Error('Not authorized, no token');
  }

  try {
    // In a real Node app: const decoded = jwt.verify(token, JWT_SECRET);
    // For this simulation, the token is simply the user ID encoded or stored
    const userId = token.split('_')[1]; 
    const user = await (User as any).findById(userId).select('-password');
    
    if (!user) {
      throw new Error('Not authorized, user not found');
    }

    return user;
  } catch (error) {
    throw new Error('Not authorized, token failed');
  }
};

export const admin = (user: any) => {
  if (user && user.role === 'admin') {
    return true;
  } else {
    throw new Error('Not authorized as an admin');
  }
};
