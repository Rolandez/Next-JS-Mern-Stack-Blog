
// Browser-compatible Mongoose Shim
// This allows the app to use MERN-style syntax (.find, .save, etc.) in a browser environment.

const getStorageKey = (name: string) => `bloom_db_${name.toLowerCase()}s`;

class MockModel {
  name: string;
  schema: any;

  constructor(name: string, schema: any) {
    this.name = name;
    this.schema = schema;
  }

  private _getData(): any[] {
    const data = localStorage.getItem(getStorageKey(this.name));
    return data ? JSON.parse(data) : [];
  }

  private _setData(data: any[]) {
    localStorage.setItem(getStorageKey(this.name), JSON.stringify(data));
  }

  async find(query: any = {}) {
    let data = this._getData();
    // Simple filter simulation
    return data.filter(item => {
      return Object.keys(query).every(key => item[key] === query[key]);
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async findOne(query: any) {
    const results = await this.find(query);
    return results[0] || null;
  }

  async findById(id: string) {
    return (await this.find()).find(item => item._id === id) || null;
  }

  async findByIdAndUpdate(id: string, update: any, options: any = {}) {
    let data = this._getData();
    const index = data.findIndex(item => item._id === id);
    if (index === -1) return null;
    data[index] = { ...data[index], ...update, updatedAt: new Date().toISOString() };
    this._setData(data);
    return data[index];
  }

  async findByIdAndDelete(id: string) {
    let data = this._getData();
    const filtered = data.filter(item => item._id !== id);
    this._setData(filtered);
    return { deletedCount: 1 };
  }

  // Constructor for instances
  createInstance(data: any) {
    const modelInstance = {
      ...data,
      _id: data._id || Math.random().toString(36).substr(2, 9),
      createdAt: data.createdAt || new Date().toISOString(),
      updatedAt: data.updatedAt || new Date().toISOString(),
      save: async () => {
        let allData = this._getData();
        const existingIndex = allData.findIndex(item => item._id === modelInstance._id);
        if (existingIndex > -1) {
          allData[existingIndex] = { ...modelInstance, updatedAt: new Date().toISOString() };
        } else {
          allData.push(modelInstance);
        }
        this._setData(allData);
        return modelInstance;
      }
    };
    return modelInstance;
  }
}

const mongooseSim: any = {
  models: {},
  Schema: class {
    definition: any;
    constructor(definition: any) { this.definition = definition; }
  },
  model: function(name: string, schema: any) {
    if (this.models[name]) return this.models[name];
    const model = new MockModel(name, schema);
    // Return a function that can be used as a constructor
    const constructor: any = function(data: any) {
      return model.createInstance(data);
    };
    // Attach static methods to the constructor
    Object.setPrototypeOf(constructor, model);
    this.models[name] = constructor;
    return constructor;
  },
  connect: async () => {
    console.log("Simulated MongoDB Connected (LocalStorage)");
    return { connection: { host: 'localhost' } };
  }
};

export default mongooseSim;
