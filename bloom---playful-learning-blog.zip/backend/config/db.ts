
import mongoose from '../lib/mongoose-shim';

const connectDB = async () => {
  try {
    await mongoose.connect();
    
    // Seed initial admin user if DB is empty
    const User = mongoose.model('User');
    const existing = await User.find({ email: 'admin@bloom.com' });
    if (existing.length === 0) {
      const admin = new User({
        name: 'Sarah Bloom',
        email: 'admin@bloom.com',
        password: 'password', // Simple simulation
        role: 'admin'
      });
      await admin.save();
    }
  } catch (error: any) {
    console.error(`Error: ${error.message}`);
  }
};

export default connectDB;
