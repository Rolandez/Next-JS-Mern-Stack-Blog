
import Post from '../models/Post';
import connectDB from '../config/db';

export const getPosts = async () => {
  await connectDB();
  return await Post.find({});
};

export const getPostBySlug = async (slug: string) => {
  await connectDB();
  return await Post.findOne({ slug });
};

export const createPost = async (postData: any, authorName: string) => {
  await connectDB();
  const post = new Post({
    ...postData,
    author: authorName,
    createdAt: new Date().toISOString()
  });
  return await post.save();
};

export const updatePost = async (id: string, postData: any) => {
  await connectDB();
  return await Post.findByIdAndUpdate(id, postData, { new: true });
};

export const deletePost = async (id: string) => {
  await connectDB();
  return await Post.findByIdAndDelete(id);
};
