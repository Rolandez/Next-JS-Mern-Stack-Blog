
import User from '../models/User';
import connectDB from '../config/db';

export const loginUser = async (email: string, pass: string) => {
  await connectDB();
  
  const user = await (User as any).findOne({ email });

  // In real app, use bcrypt.compare(pass, user.password)
  if (user && (user.password === pass)) {
    return {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: `token_${user._id}`, // Simulated JWT
    };
  } else {
    throw new Error('Invalid email or password');
  }
};

export const getUserProfile = async (userId: string) => {
  await connectDB();
  const user = await (User as any).findById(userId).select('-password');
  return user;
};
