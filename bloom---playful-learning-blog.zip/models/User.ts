
// This file is deprecated. Use backend/models/User.ts instead.
export {};
