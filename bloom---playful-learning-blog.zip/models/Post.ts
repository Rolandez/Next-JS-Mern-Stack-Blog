
// This file is deprecated. Use backend/models/Post.ts instead.
export {};
