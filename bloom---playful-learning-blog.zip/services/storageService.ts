// Deprecated: Use frontend/services/postService.ts instead.
export {};