
export type Category = 'Education' | 'Creative' | 'Storytelling' | 'Growth' | 'Technology';
export type UserRole = 'admin' | 'editor' | 'user';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  image?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: any; // TipTap JSON structure
  excerpt: string;
  featuredImage: string;
  category: Category;
  author: string; // Could be User.name or User.id
  status: 'Published' | 'Draft';
  createdAt: string;
  updatedAt: string;
}

export interface AdminStats {
  totalPosts: number;
  drafts: number;
  published: number;
}
